package syntaxAnalyser;

import java.io.BufferedWriter;

public interface TreeNode {
    public void output(BufferedWriter writer);
}
