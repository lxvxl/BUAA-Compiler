package syntaxAnalyser.nodes;

import error.ParsingFailedException;
import lexical.LexicalManager;
import logger.Logger;
import syntaxAnalyser.TreeNode;

import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.List;

public class Decl implements TreeNode {
    private final List<TreeNode> children;

    private Decl(List<TreeNode> children) {
        this.children = children;
    }

    //Decl → ConstDecl | VarDecl
    public static Decl parse(LexicalManager lm) throws ParsingFailedException {
        List<TreeNode> children = new ArrayList<>();
        TreeNode node;
        lm.mark();
        Logger.write("s开始解析 Decl");

        try {
            children.add(ConstDecl.parse(lm));
            lm.revokeMark();
            Logger.write("e解析 Decl 成功");
            return new Decl(children);
        } catch (ParsingFailedException ignored) {}

        try {
            children.add(VarDecl.parse(lm));
            lm.revokeMark();
            Logger.write("e解析 Decl 成功");
            return new Decl(children);
        } catch (ParsingFailedException e) {
            lm.traceBack();
            Logger.write("e解析 Decl 失败");
            throw e;
        }
    }

    @Override
    public void output(BufferedWriter writer) {
        for (TreeNode node: children) {
            node.output(writer);
        }
    }
}
