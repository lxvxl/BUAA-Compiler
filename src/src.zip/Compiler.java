import lexical.LexicalAnalyser;
import lexical.LexicalManager;
import lexical.Reader;
import lexical.Symbol;

import java.io.BufferedWriter;
import java.io.FileWriter;

import error.ParsingFailedException;
import logger.Logger;
import syntaxAnalyser.TreeNode;
import syntaxAnalyser.nodes.CompUnit;

public class Compiler {
    public static void main(String[] args) throws Exception {
        //Reader reader = new Reader("testfile.txt");
        //LexicalAnalyser lexicalAnalyser = new LexicalAnalyser(reader);
        //Logger.open();
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("output.txt"));
        LexicalManager lm = new LexicalManager("testfile.txt");
        TreeNode root = CompUnit.parse(lm);
        root.output(bufferedWriter);
        bufferedWriter.close();
    }

}
